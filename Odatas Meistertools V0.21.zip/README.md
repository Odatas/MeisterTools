# MeisterTools

Alpha 0.20

- Gefahrenübersicht
Ein neues Fenster in dem man sich fü eine Region Monster und Wieldtiere anzeigen lassen kann. Mit der dazugehörigen Quelle wo man die Daten zu den Tiefen findet. Im Moment sind Bestiarium 1 und 2 eingepflegt. Durchaus werden speter auch selbst kreirte Monster vorkommen die dann mit allen Infos und allen Stats dort drin stehen. Ich schau mal das ich in Kontakt mit Ulisses komme und wenigstens noch die Stats anzeigen darf. An dieser Stelle ein großes Dankeschön an /u/Panda50223 (reddit.com). Dieser hat unermüdlich die Daten für die Datenbank in ne Excel Tabelle gehämmert. 
- Simulationsmodus für die Berechnung der Wegstrecke. Dies wirkt sich auf Reisedauer und Proviantkosten aus. Von Perfekt bis Schlecht kann man hier Umwelteinflüsse und Wegstrecke einstellen. Im Orkan durch unbefestigte Pfade kommt man deutlich weniger vorran als im Sonnenschein auf gepflasterten Straßen. Es gibt für den Weg selbst 4 Einstellung und für zusätzlich den Simulationsmodus und den Einfachen Modus. Ich bitte um Rückmeldung bezüglich des Balancing. Im Einfachen modus wird lediglich ein Fixer wert dazu addiert. Im Simulationsmodus wird jeder einzelne Tag simuliert mit Zufallszahlen. Leider ist mir aufgefallen das je länger die Reise geht desto mehr geht es der Normalverteilung entgegen. Da muss ich also nochmal ran. 
- Email Adresse eingefügt. Wenn man nach Feedback per Mail fragt sollte man auch eine mailadresse einfügen ;)

Alpha 0.12

- Visuelle umstellung:
Wegen umstellung von tkinter auf ttkinter wurden die Visuellen eingenheiten erstmal zurückgedrecht. 
- Combobox gegen normale Combobox ausgetauscht:
Da in Tkinter keine Combobox vorhanden war hab ich auf ttkinter umgestellt so dass jetzt die das ganze Visuelle auf dem Standart      Windows aufbaut.
- Wegqualität:
Man kann nun einstellen welche Qualität der Weg hat und wie das Wetter ist
Perfekter weg ist gepflastert und ohne bei Sonnenschein befahrbar
Guter weg ist meist Gepflastert und nur selten durch Regen erschwert
Mittelweg ist schlechter Reiseweg mitunter und problematisches Wetter
Schlechter ist grauenhafter Reiseweg und mieses wetter. 
All das hat einflüsse auf die Reisedauer und Proviant
- Überschrift:
Überschrift wurde angepasst.


Alpha 0.11:

- Reisetools Visuals etwas entzerrt und verbessert.
- Tabelle für alle Proviant und Transportmittel hinzugefügt falls Spieler auf Handeln würfeln wollen. 
- Rundungsfilter hinzugefügt. Manche Helden machen sich nichts aus Kreuzern und Hellern. Mit dem Rundungsfilter kann man einstellen welche die kleinste Währung ist die angezeigt werden soll.




Alpha 0.1:

Rudimentärerer Beginn mit zaghaften Reisetools
